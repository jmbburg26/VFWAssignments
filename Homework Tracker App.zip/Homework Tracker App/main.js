//John Brandenburg
//Assignment 2
//Term: 0113

//User Data Values
var userName = document.getElementById("fname");
var userEmail = document.getElementById("email");
var userCourse = document.getElementById("course");
var userDueDate = document.getElementById("date");
var userNotes = document.getElementById("textarea");


var getData = function(){
	localStorage.setItem("Full Name", fname.value);
	localStorage.setItem("Email", userEmail.value);
	localStorage.setItem("Course", userCourse.value);
	localStorage.setItem("Assignment Due", userDueDate.value);
	localStorage.setItem("Notes", userNotes.value);
};

fname.addEventListener("blur", getData);
userEmail.addEventListener("blur", getData);
userCourse.addEventListener("blur", getData);
userDueDate.addEventListener("blur", getData);
userNotes.addEventListener("blur", getData);

for(i=0, j=localStorage.length; i<j; i++){
	console.log(localStorage.key(i));
};