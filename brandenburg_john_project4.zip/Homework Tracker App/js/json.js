var json = {
	"assignment1": {
		"fname": ["First Name:", "Amanda"],
		"lname": ["Last Name:", "Brandenburg"],
		"email": ["Email:", "mrsjmbburg@gmail.com"],
		"course": ["Course:", "SDI"],
		"answer": ["Project Due:", "No"],
		"date": ["Due Date:", "2013-03-15"],
		"notes": ["Notes:","Are you enjoying School?"],
		"complete": ["Hours to Complete:","1"]
	},
	"assignment2": {
		"fname": ["First Name:", "John"],
		"lname": ["Last Name:", "Brandenburg"],
		"email": ["Email:", "jmbburg26@gmail.com"],
		"course": ["Course:", "VFW"],
		"answer": ["Project Due:", "Yes"],
		"date": ["Due Date:", "2013-01-31"],
		"notes": ["Notes:","Last project!!!"],
		"complete": ["Hours to Complete:","8"]
	},
	"assignment3": {
		"fname": ["First Name:", "Allan"],
		"lname": ["Last Name:", "Bladorn"],
		"email": ["Email:", "anb122410@gmail.com"],
		"course": ["Course:", "PMA"],
		"answer": ["Project Due:", "Unknown"],
		"date": ["Due Date:", "2013-04-7"],
		"notes": ["Notes:","Is it over?"],
		"complete": ["Hours to Complete:","8"]
	}
}